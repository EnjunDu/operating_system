#include "types.h"
#include "user.h"

int
main(void)
{
  int pid = fork();  // 创建一个子进程
  
  if(pid == 0) {
    // 子进程
    for(int i = 0; i < 100000000; i++) {
      asm volatile("nop");  // 模拟一些工作
    }
    exit();  // 子进程退出
  } else {
    wait();  // 父进程等待子进程退出
    get_sched_performance(pid);  // 调用新系统调用获取调度性能
  }

  exit();
}
