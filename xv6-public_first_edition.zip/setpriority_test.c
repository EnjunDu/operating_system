#include "types.h"
#include "stat.h"
#include "user.h"

int main() {
  int pid = fork();  // 创建子进程

  if (pid == 0) {
    // 子进程，设置优先级为 15（较高的优先级）
    setpriority(getpid(), 15);
    while (1) {
      printf(1, "Child running with priority 15\n");
      sleep(100);
    }
  } else {
    // 父进程，设置优先级为 5（较低的优先级）
    setpriority(getpid(), 5);
    while (1) {
      printf(1, "Parent running with priority 5\n");
      sleep(100);
    }
  }

  return 0;
}

