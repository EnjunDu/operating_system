#include "types.h"
#include "stat.h"
#include "user.h"

#define NUM_PROCS 5  // 定义子进程数量
#define RUN_TIME 100 // 每个子进程运行的时间片

void do_work(int priority) {
    int i;
    setpriority(getpid(), priority);  // 设置进程优先级
    printf(1, "Process %d started with priority %d\n", getpid(), priority);
    
    for (i = 0; i < RUN_TIME; i++) {
        printf(1, "Process %d is running with priority %d, iteration %d\n", getpid(), priority, i);
        sleep(10);  // 模拟一些工作，避免独占CPU
    }
    printf(1, "Process %d finished with priority %d\n", getpid(), priority);
}

int main(void) {
    int pids[NUM_PROCS];  // 保存子进程的pid
    int initial_priority = 5;

    // 创建多个子进程，每个子进程设置不同的初始优先级
    for (int i = 0; i < NUM_PROCS; i++) {
        pids[i] = fork();
        if (pids[i] == 0) {  // 子进程
            do_work(initial_priority + i * 5);  // 设置初始优先级，逐渐增高
            exit();  // 结束子进程
        }
    }

    // 父进程负责监控每个子进程
    for (int i = 0; i < NUM_PROCS; i++) {
        wait();  // 等待每个子进程结束
        printf(1, "Process %d exited\n", pids[i]);
    }

    // 父进程结束
    printf(1, "All child processes have exited.\n");
    exit();
}

