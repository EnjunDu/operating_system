#include "types.h"
#include "stat.h"
#include "user.h"

int lock = 0; // 锁状态，0表示未锁定，1表示锁定

// 模拟获取锁
void acquire_lock(int *lk) {
    while (*lk == 1) {
        // 自旋等待锁释放
    }
    *lk = 1;  // 获取锁
}

// 模拟释放锁
void release_lock(int *lk) {
    *lk = 0;  // 释放锁
}

// 模拟低优先级任务
void low_priority_task() {
    acquire_lock(&lock);  // 获取锁
    printf(1, "Low priority task running...\n");

    // 模拟延迟操作
    for (int i = 0; i < 100000000; i++) {
        asm volatile("nop");  // 占用 CPU
    }

    printf(1, "Low priority task finished.\n");
    release_lock(&lock);  // 释放锁
}

// 模拟高优先级任务
void high_priority_task() {
    printf(1, "High priority task trying to acquire lock...\n");

    acquire_lock(&lock);  // 尝试获取锁

    printf(1, "High priority task running...\n");

    release_lock(&lock);  // 释放锁
}

int main() {
    int pid_low = fork();
    if (pid_low == 0) {
        setpriority(getpid(), 5);  // 低优先级进程
        low_priority_task();
        exit();
    }

    // 等待低优先级进程开始执行
    sleep(50);

    int pid_high = fork();
    if (pid_high == 0) {
        setpriority(getpid(), 20);  // 高优先级进程
        high_priority_task();
        exit();
    }

    wait();  // 等待子进程
    wait();  // 等待子进程
    exit();
}

