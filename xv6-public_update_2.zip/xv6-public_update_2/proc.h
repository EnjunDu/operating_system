#ifndef PROC_H
#define PROC_H

#include "types.h"       // 基本数据类型
#include "mmu.h"         // 内存管理单元相关定义
#include "param.h"       // 系统参数
#include "x86.h"         // x86 特定定义
#include "fs.h"          // 文件系统相关定义
#include "spinlock.h"    // 自旋锁

// 每个 CPU 的状态
struct cpu {
  uchar apicid;                 // 本地 APIC ID
  struct context *scheduler;    // 切换到此上下文以进入调度器
  struct taskstate ts;          // 用于 x86 找到中断堆栈
  struct segdesc gdt[NSEGS];    // x86 全局描述符表
  volatile uint started;        // CPU 是否已启动
  int ncli;                     // pushcli 嵌套的深度
  int intena;                   // 中断启用标志
  struct proc *proc;            // 当前在此 CPU 上运行的进程
};

extern struct cpu cpus[NCPU];
extern int ncpu;

// 保存的寄存器用于内核上下文切换，不需要保存所有段寄存器（%cs 等），
// 因为它们在内核上下文之间是常量。%eax, %ecx, %edx 不需要保存，
// 因为 x86 约定调用者已保存它们。
struct context {
  uint edi;
  uint esi;
  uint ebx;
  uint ebp;
  uint eip;
};

// 进程状态的枚举
enum procstate { UNUSED, EMBRYO, SLEEPING, RUNNABLE, RUNNING, ZOMBIE };

// 每个进程的状态结构定义
struct proc {
  uint sz;                      // 进程内存大小（字节）
  pde_t* pgdir;                 // 页表指针
  char *kstack;                 // 内核堆栈的底部指针
  enum procstate state;         // 进程状态
  int pid;                      // 进程 ID
  struct proc *parent;          // 父进程
  struct trapframe *tf;         // 当前系统调用的 Trap Frame
  struct context *context;      // swtch() 调用的上下文
  void *chan;                   // 非零时表示正在等待的通道
  int killed;                   // 非零表示进程被杀死
  struct file *ofile[NOFILE];   // 打开的文件
  struct inode *cwd;            // 当前目录
  char name[16];                // 进程名称（用于调试）
  int priority;                 // 进程优先级
  int aging_ticks;    // 累计等待的时钟周期
  int donated_priority;  // 被捐献的优先级
  struct spinlock *lock_holding;  // 持有的锁
};

#endif // PROC_H

