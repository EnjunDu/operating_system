// Mutual exclusion spin locks.

#include "types.h"
#include "defs.h"
#include "param.h"
#include "x86.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "spinlock.h"

void
initlock(struct spinlock *lk, char *name)
{
  lk->name = name;
  lk->locked = 0;
  lk->cpu = 0;
}

// Acquire the lock.
// Loops (spins) until the lock is acquired.
// Holding a lock for a long time may cause
// other CPUs to waste time spinning to acquire it.
void acquire(struct spinlock *lk) {
    pushcli(); // 禁用中断

    if(holding(lk))
        panic("acquire");

    // 获取当前持有锁的进程
    struct proc *holder = myproc()->lock_holding;

    // 如果锁已被持有，并且持有者的优先级低于当前进程，则进行优先级捐献
    if (lk->locked && holder && holder->priority < myproc()->priority) {
        // 记录持有者的原始优先级，并捐献优先级
        holder->donated_priority = myproc()->priority;
        cprintf("Priority donation: process %d donates priority to process %d\n", myproc()->pid, holder->pid);
    }

    // 获取锁
    while(xchg(&lk->locked, 1) != 0)
        ;
    __sync_synchronize();

    // 当前进程持有锁
    myproc()->lock_holding = lk;
}


// Release the lock.
void release(struct spinlock *lk) {
    if(!holding(lk))
        panic("release");

    struct proc *holder = myproc();

    // 如果持有锁的进程曾经获得过优先级捐献，在释放锁时恢复原始优先级
    if (holder->donated_priority != 0) {
        holder->priority = holder->donated_priority;
        holder->donated_priority = 0;  // 清除捐献的优先级
        cprintf("Priority restored: process %d restores its original priority\n", holder->pid);
    }

    // 清除锁的持有状态
    holder->lock_holding = 0;

    __sync_synchronize();
    xchg(&lk->locked, 0);
    popcli();
}



// Record the current call stack in pcs[] by following the %ebp chain.
void
getcallerpcs(void *v, uint pcs[])
{
  uint *ebp;
  int i;

  ebp = (uint*)v - 2;
  for(i = 0; i < 10; i++){
    if(ebp == 0 || ebp < (uint*)KERNBASE || ebp == (uint*)0xffffffff)
      break;
    pcs[i] = ebp[1];     // saved %eip
    ebp = (uint*)ebp[0]; // saved %ebp
  }
  for(; i < 10; i++)
    pcs[i] = 0;
}

// Check whether this cpu is holding the lock.
int
holding(struct spinlock *lock)
{
  int r;
  pushcli();
  r = lock->locked && lock->cpu == mycpu();
  popcli();
  return r;
}


// Pushcli/popcli are like cli/sti except that they are matched:
// it takes two popcli to undo two pushcli.  Also, if interrupts
// are off, then pushcli, popcli leaves them off.

void
pushcli(void)
{
  int eflags;

  eflags = readeflags();
  cli();
  if(mycpu()->ncli == 0)
    mycpu()->intena = eflags & FL_IF;
  mycpu()->ncli += 1;
}

void
popcli(void)
{
  if(readeflags()&FL_IF)
    panic("popcli - interruptible");
  if(--mycpu()->ncli < 0)
    panic("popcli");
  if(mycpu()->ncli == 0 && mycpu()->intena)
    sti();
}

